# 문서 세트 안내

이 폴더는 입력 설계서를 Claude Code 프로젝트용 운영 문서 세트로 재구성한 결과물이다.

## 구성
- `CLAUDE.md` : Claude Code가 매 세션마다 먼저 읽어야 하는 핵심 작업 기준서
- `docs/project_scope_and_goals.md` : 배경, 목적, 범위, 제약, 용어
- `docs/source_strategy.md` : 데이터 소스 계층, 우선순위, 증분 규칙
- `docs/workflow_and_states.md` : 전체 흐름, 상태 전이, 단계별 처리 정의
- `docs/ai_and_script_role_split.md` : LLM/에이전트와 스크립트 역할 분리 상세
- `docs/tokenization_and_normalization.md` : 토큰화, 정규화, 티어링 정책
- `docs/storage_and_dedup.md` : 저장 구조, exact registry, dedupe 알고리즘
- `docs/testing_and_qa.md` : QA 방식, 검증 패턴, 완료 기준
- `docs/implementation_structure.md` : 폴더 구조, 기술 스택, 로드맵
- `docs/operations_runbook.md` : 운영 절차와 장애 대응
- `docs/omission_crosswalk.md` : 원본 설계서 대비 누락 0% 대조표

## 사용 방식
1. 프로젝트 루트에 `CLAUDE.md`를 둔다.
2. `docs/` 폴더를 함께 둔다.
3. Claude Code가 실제 프로젝트를 생성/수정/검증할 때 `CLAUDE.md`를 우선 기준으로 삼고, 세부 규칙은 `docs/`를 참조하게 한다.
