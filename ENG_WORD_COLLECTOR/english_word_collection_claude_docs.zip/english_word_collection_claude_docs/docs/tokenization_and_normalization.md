# 토큰화와 정규화 정책

## 1. 기본 정책
수집량 최대화가 목적이므로 **보수적 필터링보다 넓은 추출 후 티어링**을 사용한다.

## 2. 추출 대상 예시
- 알파벳만: `hello`
- 알파벳+숫자: `h264`, `mp3`, `i18n`
- 아포스트로피 포함: `don't`, `rock'n'roll`
- 하이픈 포함: `state-of-the-art`
- 대문자 유지형: `NASA`, `OpenAI`
- 점 포함 약어: `u.s.a.` 는 별도 보존 정책 검토

## 3. 정규화 레벨
### level 0: raw preserve
- 원문 그대로 저장

### level 1: compare normalization
- Unicode NFKC
- 앞뒤 공백 제거
- 제어문자 제거
- 필요 시 연속 내부 공백 collapse

### level 2: canonical compare key
- casefold key 별도 생성
- 특정 문장부호 정리 key 별도 생성 가능

## 4. dedupe 기준
- 기본 원칙: `token_canonical` 기준 dedupe
- raw variant는 별도 저장 가능
- 예시 정책:
  - `OpenAI` / `openai` → canonical 동일 처리 가능
  - `co-operate` / `cooperate` → 동일 처리 여부를 정책으로 분리

## 5. 품질 티어링
- `tier_1_lexicon`
- `tier_2_entity`
- `tier_3_web_clean`
- `tier_4_web_longtail`
- `tier_5_noisy`

## 6. 주의사항
- 수집량 최대화 목표를 이유로 canonical 정책을 느슨하게 바꿔 기존 dedupe 안정성을 깨뜨리면 안 된다.
- 과병합이 의심되면 자동 확정하지 말고 collision sample을 남긴다.
