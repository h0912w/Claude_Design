# 원본 설계서 대비 누락 0% 대조표

이 문서는 원본 설계서의 주요 항목이 최종 산출물 어디에 반영되었는지 추적하기 위한 교차표다.

## 1. 작업 컨텍스트 문서
- 작업명 → `CLAUDE.md`, `docs/project_scope_and_goals.md`
- 배경 → `docs/project_scope_and_goals.md`
- 목적 → `CLAUDE.md`, `docs/project_scope_and_goals.md`
- 범위(포함/제외) → `CLAUDE.md`, `docs/project_scope_and_goals.md`
- 입력 → `CLAUDE.md`, `docs/project_scope_and_goals.md`
- 출력 → `CLAUDE.md`, `docs/project_scope_and_goals.md`
- 주요 제약조건 → `CLAUDE.md`, `docs/project_scope_and_goals.md`
- 핵심 설계 원칙 → `CLAUDE.md`, `docs/project_scope_and_goals.md`
- 용어 정의 → `docs/project_scope_and_goals.md`

## 2. 수집 전략 개요
- 4계층 전략 → `docs/source_strategy.md`
- 왜 이 구조가 필요한가 → `docs/source_strategy.md`
- 현실적 한계 / 오픈엔드 정의 → `docs/project_scope_and_goals.md`

## 3. 데이터 소스 설계
- 1차 우선 소스 A~F → `docs/source_strategy.md`
- 2차 확장 소스 → `docs/source_strategy.md`
- 소스 우선순위 → `CLAUDE.md`, `docs/source_strategy.md`

## 4. 워크플로우 정의
- 전체 흐름 → `CLAUDE.md`, `docs/workflow_and_states.md`
- 상태 전이 → `docs/workflow_and_states.md`
- 다중 AI 더블체크 공통 프로토콜 → `CLAUDE.md`, `docs/ai_and_script_role_split.md`
- 단계 1~10 정의 → `docs/workflow_and_states.md`

## 5. 판단과 코드의 역할 분리
- 본문 포함 요구 → `CLAUDE.md`
- 상세 분리표 → `docs/ai_and_script_role_split.md`
- 에이전트/스크립트 구분 → `CLAUDE.md`, `docs/ai_and_script_role_split.md`

## 6. 반복 실행 시 중복 없이 누적 추가하는 구조
- Fast Seen Filter → `CLAUDE.md`, `docs/storage_and_dedup.md`
- Exact Seen Registry → `CLAUDE.md`, `docs/storage_and_dedup.md`
- Token Warehouse → `CLAUDE.md`, `docs/storage_and_dedup.md`
- 신규 단어 추가 알고리즘 → `docs/storage_and_dedup.md`
- exact registry 필요성 → `docs/storage_and_dedup.md`
- 실행 재개 방식 → `docs/storage_and_dedup.md`
- 증분 소스 선택 규칙 → `docs/source_strategy.md`

## 7. 저장 구조 설계
- raw/stage/warehouse 분리 → `CLAUDE.md`, `docs/storage_and_dedup.md`
- Parquet / LMDB(RocksDB) / DuckDB 조합 → `CLAUDE.md`, `docs/storage_and_dedup.md`
- 권장 스키마 → `CLAUDE.md`, `docs/storage_and_dedup.md`
- AI 활용용 export → `docs/storage_and_dedup.md`

## 8. 토큰화 및 정규화 정책
- 기본 정책 → `CLAUDE.md`, `docs/tokenization_and_normalization.md`
- 토큰 추출 규칙 예시 → `docs/tokenization_and_normalization.md`
- 정규화 레벨 → `docs/tokenization_and_normalization.md`
- dedupe 기준 → `CLAUDE.md`, `docs/tokenization_and_normalization.md`
- 품질 티어링 → `docs/tokenization_and_normalization.md`

## 9. 구현 스펙
- 폴더 구조 → `docs/implementation_structure.md`
- CLAUDE.md 핵심 섹션 목록 → `CLAUDE.md`
- 에이전트 구조와 이유 → `docs/ai_and_script_role_split.md`, `docs/implementation_structure.md`
- 서브에이전트 정의 → `docs/ai_and_script_role_split.md`
- 단계별 처리 방식 → `docs/workflow_and_states.md`, `docs/ai_and_script_role_split.md`
- 스킬/스크립트 목록 및 트리거 조건 → `docs/implementation_structure.md` 내 방향성 반영
- 주요 산출물 파일 형식 → `docs/storage_and_dedup.md`, `docs/implementation_structure.md`

## 10. 검증 패턴
- 단계별 성공 기준 / 검증 방법 / 실패 처리 → `docs/testing_and_qa.md`

## 11. 실패 처리 정책
- 자동 재시도 → `CLAUDE.md`, `docs/testing_and_qa.md`
- 에스컬레이션 → `CLAUDE.md`, `docs/testing_and_qa.md`
- 스킵 + 로그 → `CLAUDE.md`, `docs/testing_and_qa.md`

## 12. 로컬 PC 운영 설계
- 권장 환경 → `CLAUDE.md`, `docs/implementation_structure.md`
- 디스크 운영 원칙 → `docs/operations_runbook.md`
- 실행 모드 → `docs/implementation_structure.md`

## 13. 권장 기술 스택
- 기술 스택 및 선택 이유 → `CLAUDE.md`, `docs/implementation_structure.md`

## 14. 실행 로드맵
- Phase 1~4 → `docs/implementation_structure.md`

## 15. 최종 권고안
- 프로젝트 정의 / 수집 소스 / dedupe 구조 / 저장 구조 / 운영 구조 / 에이전트 구조 → `CLAUDE.md`, 보조 문서 전반

## 16. 참고 소스 주소 목록
- 실제 URL 목록은 원본 설계서에 존재하며, 구현 시 `config/source_registry.yaml` 또는 별도 참조 자료로 반영한다.
- 본 문서 세트에서는 운영 규칙 중심으로 유지하되, 소스명과 계층은 `docs/source_strategy.md`에 보존했다.

## 누락 점검 결론
- 설계서의 구조적 요구사항은 `CLAUDE.md + docs/*` 조합으로 반영했다.
- 특히 **LLM 처리 영역과 스크립트 처리 영역 분리 항목은 `CLAUDE.md` 본문에 직접 유지**했다.
- **누락 0% 더블체크 문서로 이 파일을 포함**한다.
