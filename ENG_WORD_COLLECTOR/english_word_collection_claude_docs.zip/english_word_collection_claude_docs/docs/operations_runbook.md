# 운영 런북

## 1. 운영 원칙
- raw와 warehouse를 분리한다.
- 다운로드 원본은 보관 기간 정책을 둔다.
- stage 결과는 재생성 가능하면 주기적으로 정리한다.
- shard compaction 주기를 운영한다.
- 저장소가 커질수록 메모리 전체 적재를 금지한다.

## 2. 실행 순서
1. `source_registry.yaml` 점검
2. 이전 실행 marker / harvest history 점검
3. incremental plan 생성
4. 다운로드/크롤링
5. 파싱
6. 토큰 추출
7. 정규화
8. dedupe
9. 저장소 커밋
10. 품질 분석
11. 리포트 및 marker 업데이트

## 3. 운영 중 확인 항목
- raw 저장 용량
- registry 무결성
- shard 크기 편차
- run별 신규 단어 수 급감/급증 여부
- 노이즈 비율 급상승 여부
- crawl/dump 버전 갱신 여부

## 4. 장애 대응
- 네트워크/다운로드 문제: 재시도 후 로그 유지
- 포맷 이상치: 샘플과 오류 로그를 별도 저장
- registry 이상: 쓰기 중지 후 진단
- 디스크 부족: raw 정리 또는 shard compaction 검토
- reviewer 충돌: tie-breaker 판정 또는 수동 검토

## 5. 운영 산출물
- run report
- source coverage
- quality report
- failure / retry logs
- export artifacts
