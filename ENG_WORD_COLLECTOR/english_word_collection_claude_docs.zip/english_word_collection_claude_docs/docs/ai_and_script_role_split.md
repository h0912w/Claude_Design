# 판단과 코드의 역할 분리 상세

## 1. 공통 원칙
- 결정론적·대용량·반복 실행 로직은 스크립트가 수행한다.
- 정책 선택, 이상 징후 해석, 규칙 조정, 품질 분석은 LLM/에이전트가 수행한다.
- 자동 규칙 변경이 저장 계약을 깨뜨릴 가능성이 있으면 사용자 확인으로 넘긴다.

## 2. 단계별 역할 분리 표

| 업무 | 에이전트가 직접 수행 | 스크립트로 처리 |
|---|---|---|
| 소스 우선순위 판단 | O | 소스 목록 로드, 이력 비교 |
| 신규 소스 채택 판단 | O | URL 검증, 메타데이터 저장 |
| 증분 수집 계획 결정 | O | last_success 비교, 배치 생성 |
| 파서 정책 선택 | O | XML/JSONL/WET/WARC 스트리밍 파싱 |
| 토큰화 규칙 개선 | O | regex tokenizer 실행 |
| 정규화 정책 검토 | O | unicode 정규화, 해시 생성 |
| 중복 제거 이상 분석 | O | Bloom/Cuckoo lookup, exact registry lookup |
| 저장 전략 최적화 | O | shard write, DB update |
| 품질/노이즈 정성 분석 | O | 규칙 기반 품질 통계 |
| 실행 요약 생성 | O | JSON/Markdown 리포트 생성 |

## 3. 다중 AI 더블체크 프로토콜
### 공통 역할
- `main-orchestrator`
- `domain-primary-agent`
- `consensus-reviewer-a`
- `consensus-reviewer-b`
- `consensus-tiebreaker`

### 공통 절차
1. 스크립트 초안 또는 1차 판단안 생성
2. reviewer A/B가 서로의 답을 보지 않고 독립 검토
3. 3개 중 2개가 일치하면 승인
4. 충돌 크면 tie-breaker 판정
5. 합의 실패 시 `REVIEW_CONFLICT` 기록 후 재시도/에스컬레이션

## 4. 설계서에 정의된 구체 에이전트
- `source-strategy-planner`
- `incremental-harvest-planner`
- `download-integrity-reviewer`
- `parser-policy-agent`
- `token-policy-agent`
- `normalization-reviewer`
- `dedupe-auditor`
- `storage-strategy-agent`
- `quality-auditor`
- `report-generator`
- `consensus-reviewer-a`
- `consensus-reviewer-b`
- `consensus-tiebreaker`

## 5. 구현 시 주의
- Agent/Skills 문서는 사람이 미리 만드는 문서 세트가 아니라, 실제 프로젝트 생성 과정에서 Claude Code가 생성하도록 한다.
- 이번 산출물에서는 Agent/Skills 자체를 작성하지 않고, Claude Code가 그것들을 생성할 수 있도록 규칙과 구조를 제공한다.
