# 데이터 소스 전략

## 1. 전체 소스 계층
1. 고품질 사전 계층
2. 대규모 웹 코퍼스 계층
3. 타이틀/엔티티 계층
4. 증분 확장 계층

## 2. 왜 이 구조를 쓰는가
- 사전/워드리스트만으로는 규모 확장이 제한된다.
- Common Crawl 같은 웹 코퍼스는 신조어, 약어, 고유명사, 오타성 표기까지 대량 확보할 수 있다.
- 따라서 목표가 수억 개 이상이라면 고품질 seed + 웹 대량 확장이 모두 필요하다.

## 3. 1차 우선 소스(반드시 구현)
### A. Common Crawl
- 목적: 초대규모 웹 텍스트 확보
- 방식: WET 파일 우선, 필요 시 WARC/인덱스 보조
- 추출 대상: 일반 웹문서 본문, 블로그, 포럼, 문서 사이트, 쇼핑몰, 뉴스, 개발문서
- 운영 원칙: 월별 신규 crawl을 증분 대상으로 삼는다.

### B. English Wiktionary dump
- 목적: 고품질 사전형 단어층 확보
- 추출 대상: 표제어, 변형 표기, 영어 항목 내 단어형

### C. Kaikki raw data
- 목적: 구조화된 Wiktionary 추출본 활용
- 추출 대상: English entries, forms, redirects, variant spellings

### D. SCOWL / English Speller Database
- 목적: 철자 기반 신뢰도 높은 seed 확보
- 추출 대상: dialect별 word list, inflection/variant 리스트

### E. WordNet
- 목적: 기본 영단어망 및 파생 확장 보조
- 추출 대상: lemma, multiword expression

### F. English Wikipedia titles
- 목적: 고유명사·합성어·엔티티명 확장
- 추출 대상: article title, redirect title

## 4. 2차 확장 소스
- GitHub 공개 워드리스트 저장소
- 공개 subtitle / forum / news dump
- 공개 domain-specific glossary
- 오픈소스 spell dictionary
- sitemap + 본문 크롤링 기반 도메인 확장

## 5. 소스 우선순위
1. Wiktionary / Kaikki / SCOWL / WordNet / Wikipedia titles로 seed 구축
2. Common Crawl로 대규모 확장
3. 도메인 특화 웹/워드리스트로 롱테일 확장
4. 반복 실행 시 신규 월별 크롤 및 신규 덤프만 추가

## 6. 증분 소스 선택 규칙
- Common Crawl: 이전 미처리 crawl ID만 대상
- Wiktionary / Kaikki / Wikipedia dump: 최신 dump가 이전보다 새로울 때만 대상
- 워드리스트 저장소: 체크섬/버전 변경 시만 대상
- 사용자 추가 크롤링 대상: sitemap / etag / last-modified 변화 시만 대상

## 7. 소스 관련 판단 규칙
- 소스 채택 여부는 LLM/에이전트가 판단하되, 다운로드/검증/메타기록은 스크립트가 수행한다.
- 라이선스 또는 운영 비용에 영향을 주는 신규 소스는 자동 확정하지 말고 검토 로그를 남긴다.
