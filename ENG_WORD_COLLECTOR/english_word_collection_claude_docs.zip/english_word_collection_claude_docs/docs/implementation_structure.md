# 구현 구조와 권장 기술 스택

## 1. 폴더 구조 권장안
```text
/project-root
 ├── CLAUDE.md
 ├── /config
 │   ├── source_registry.yaml
 │   ├── normalization_rules.yaml
 │   ├── tokenization_rules.yaml
 │   └── runtime.yaml
 ├── /data
 │   ├── /raw
 │   ├── /stage
 │   ├── /warehouse
 │   ├── /registry
 │   └── /catalog
 ├── /output
 │   ├── /reports
 │   ├── /exports
 │   └── /samples
 └── /docs
     ├── project_scope_and_goals.md
     ├── source_strategy.md
     ├── workflow_and_states.md
     ├── ai_and_script_role_split.md
     ├── tokenization_and_normalization.md
     ├── storage_and_dedup.md
     ├── testing_and_qa.md
     ├── implementation_structure.md
     ├── operations_runbook.md
     └── omission_crosswalk.md
```

## 2. 왜 Agent/Skills 파일을 지금 직접 만들지 않는가
설계 지침상 Agent, Skills 문서는 프로젝트 생성 과정에서 Claude Code가 생성한다. 따라서 현재 문서 세트는 Claude Code가 그것들을 일관되게 생성하도록 기준을 제공하는 역할을 한다.

## 3. 권장 기술 스택
- Python
- requests/httpx
- warcio 또는 동급 WARC parser
- lxml / streaming XML parser
- regex / custom tokenizer
- DuckDB
- PyArrow / Parquet
- LMDB 또는 RocksDB 바인딩
- zstandard

## 4. 실행 모드
- `seed-build`
- `crawl-expand`
- `incremental-update`
- `reindex-export`
- `quality-audit`

## 5. 로드맵
### Phase 1. Seed 구축
- Wiktionary
- Kaikki
- SCOWL
- WordNet
- Wikipedia titles

### Phase 2. 대규모 확장
- Common Crawl 월별 크롤 처리

### Phase 3. 증분 자동화
- 신규 crawl/dump만 처리
- exact registry 기반 누적 저장

### Phase 4. 품질 티어링 고도화
- 노이즈 패턴 분리
- 티어별 export 생성
