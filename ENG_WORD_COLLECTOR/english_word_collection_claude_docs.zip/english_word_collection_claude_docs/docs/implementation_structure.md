# 구현 구조와 권장 기술 스택

## 1. 폴더 구조 권장안
```text
/project-root
 ├── CLAUDE.md
 ├── /config
 │   ├── source_registry.yaml
 │   ├── normalization_rules.yaml
 │   ├── tokenization_rules.yaml
 │   └── runtime.yaml
 ├── /data
 │   ├── /raw
 │   ├── /stage
 │   ├── /warehouse
 │   ├── /registry
 │   └── /catalog
 ├── /output
 │   ├── /reports
 │   ├── /exports
 │   └── /samples
 └── /docs
     ├── project_scope_and_goals.md
     ├── source_strategy.md
     ├── workflow_and_states.md
     ├── ai_and_script_role_split.md
     ├── tokenization_and_normalization.md
     ├── storage_and_dedup.md
     ├── testing_and_qa.md
     ├── implementation_structure.md
     ├── operations_runbook.md
     └── omission_crosswalk.md
```


## 2. 문서 세트 구성과 배치 원칙
이 문서 세트는 README 없이도 바로 사용할 수 있어야 한다. 문서 구성 설명과 사용 방식은 아래 규칙으로 유지한다.

- `CLAUDE.md`: Claude Code가 매 세션 가장 먼저 읽는 핵심 운영 기준서
- `docs/project_scope_and_goals.md`: 배경, 목적, 범위, 제약, 용어
- `docs/source_strategy.md`: 데이터 소스 계층, 우선순위, 증분 수집 규칙
- `docs/workflow_and_states.md`: 전체 흐름, 상태 전이, 단계별 처리 정의
- `docs/ai_and_script_role_split.md`: LLM/에이전트와 스크립트 역할 분리 상세
- `docs/tokenization_and_normalization.md`: 토큰화, 정규화, 티어링 정책
- `docs/storage_and_dedup.md`: 저장 구조, exact registry, dedupe 알고리즘
- `docs/testing_and_qa.md`: QA 방식, 검증 패턴, 완료 기준
- `docs/implementation_structure.md`: 폴더 구조, 기술 스택, 문서 배치 규칙
- `docs/operations_runbook.md`: 운영 절차와 장애 대응
- `docs/omission_crosswalk.md`: 원본 설계서 대비 누락 0% 대조표

## 3. 사용 방식
1. 프로젝트 루트에 `CLAUDE.md`를 둔다.
2. 같은 루트에 `docs/` 폴더를 함께 둔다.
3. Claude Code는 `CLAUDE.md`를 1차 기준으로 사용하고, 세부 규칙은 관련 `docs/*.md`를 참조한다.
4. README 같은 별도 안내 파일은 추가하지 말고, 문서 구조 설명이 필요하면 본 문서나 `CLAUDE.md`에만 반영한다.

## 4. 왜 Agent/Skills 파일을 지금 직접 만들지 않는가
설계 지침상 Agent, Skills 문서는 프로젝트 생성 과정에서 Claude Code가 생성한다. 따라서 현재 문서 세트는 Claude Code가 그것들을 일관되게 생성하도록 기준을 제공하는 역할을 한다.

## 5. 권장 기술 스택
- Python
- requests/httpx
- warcio 또는 동급 WARC parser
- lxml / streaming XML parser
- regex / custom tokenizer
- DuckDB
- PyArrow / Parquet
- LMDB 또는 RocksDB 바인딩
- zstandard

## 6. 실행 모드
- `seed-build`
- `crawl-expand`
- `incremental-update`
- `reindex-export`
- `quality-audit`

## 7. 로드맵
### Phase 1. Seed 구축
- Wiktionary
- Kaikki
- SCOWL
- WordNet
- Wikipedia titles

### Phase 2. 대규모 확장
- Common Crawl 월별 크롤 처리

### Phase 3. 증분 자동화
- 신규 crawl/dump만 처리
- exact registry 기반 누적 저장

### Phase 4. 품질 티어링 고도화
- 노이즈 패턴 분리
- 티어별 export 생성
