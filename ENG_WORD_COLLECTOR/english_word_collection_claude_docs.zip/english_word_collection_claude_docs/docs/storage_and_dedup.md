# 저장 구조와 중복 제거

## 1. 3층 저장 구조
### 1) Fast Seen Filter
- 역할: 이미 본 해시인지 빠른 1차 판정
- 후보: Bloom Filter / Cuckoo Filter
- 특징: 빠르지만 false positive 가능

### 2) Exact Seen Registry
- 역할: 최종 중복 판정 기준
- 후보: LMDB 또는 RocksDB
- 저장 키: `token_hash64` 또는 `token_hash128`
- 저장 값: 최소 메타데이터(최초 발견 소스, 최초 발견 시각, token length, flags)

### 3) Token Warehouse
- 역할: 실제 문자열 원본 저장
- 후보: prefix/hash 기반 Parquet shard + Zstandard 압축

## 2. 신규 단어 추가 알고리즘
```text
for each extracted token:
    normalize token
    make canonical key
    hash = stable_hash(canonical key)

    if bloom_filter says "seen":
        check exact_registry
        if exists:
            skip
        else:
            insert exact_registry
            append token warehouse
            update bloom_filter
    else:
        insert exact_registry
        append token warehouse
        update bloom_filter
```

## 3. 왜 exact registry가 필요한가
Bloom/Cuckoo만 쓰면 false positive 때문에 실제 신규 단어가 누락될 수 있다. 따라서 빠른 필터는 속도용, exact registry는 정확성용이다.

## 4. 실행 재개
- `last_processed_offset`
- `last_processed_file`
- `last_processed_line`
- `crawl_id`

배치 단위 커밋을 사용해 일부만 롤백 가능하게 설계한다.

## 5. 권장 저장 구조
### 폴더
- `data/raw`
- `data/stage`
- `data/warehouse`
- `data/registry`
- `data/catalog`
- `output/reports`
- `output/exports`
- `output/samples`

### 최종 조합
- Parquet shards
- LMDB/RocksDB exact registry
- DuckDB metadata catalog
- 필요 시 `txt.zst` export

## 6. 권장 스키마
### token warehouse columns
- `token_raw`
- `token_canonical`
- `token_hash`
- `source_id`
- `source_type`
- `first_seen_at`
- `run_id`
- `token_len`
- `char_class`
- `quality_flags`
- `tier`

### catalog tables
- `runs`
- `sources`
- `source_files`
- `run_stats`
- `quality_reports`
- `shard_manifest`

## 7. AI 활용용 export
1. canonical wordlist shards
2. parquet analytics store
3. deduped flat export: `all_words_deduped.txt.zst`
