# CLAUDE.md

## 프로젝트 정의
이 프로젝트는 공개 웹·사전·덤프·코퍼스·워드리스트에서 영어 문자열 토큰을 가능한 한 많이 수집하고, **매 실행마다 기존 저장소에 없는 신규 토큰만 누적 추가**하는 로컬 기반 대용량 수집 시스템이다. 구현 목표는 “사전형 정답 단어집”이 아니라 **수억 개 이상 규모로 계속 확장 가능한 영어 문자열 수집 인프라**다.

## 절대 원칙
- 원본 설계서 요구를 누락하지 않는다.
- 수집량 최대화를 우선하되, 중복 저장은 금지한다.
- 메모리 전체 적재 방식은 금지한다. 스트리밍·샤딩·배치 커밋을 기본으로 한다.
- 고품질 사전층과 대규모 웹 후보층을 분리 저장한다.
- 실행 결과는 재현 가능해야 한다. 소스, 규칙, 배치, 시각, run_id를 기록한다.
- 사람 대상 소개문이 아니라 **Claude Code의 실행 기준서**로 동작해야 한다.

## 우선순위
1. 누락 0%
2. 기존 저장소와의 정확한 중복 방지
3. 출력/저장 계약 준수
4. 대용량 안정성
5. 증분 실행 가능성
6. 추적 가능성·로그 완전성
7. 성능 최적화
8. 코드 미관

## 범위 / 비목표
### 포함
- 일반 단어, 활용형, 파생형, 고유명사, 약어, 하이픈 단어, 합성어, 인터넷 슬랭, 고어/방언, 웹 변형 표기, 반복 등장 오타성 문자열 수집
- 반복 실행 시 신규 소스만 증분 수집
- 누적 저장소, 신규 단어 목록, 통계, 로그, 샤드, 메타DB 생성

### 제외
- 단어 의미·품사·예문 작성
- 사람 수동 편집 워크플로우
- “진짜 영어 단어만” 남기는 보수적 사전 구축
- 별도 QA 전용 소프트웨어 제작

## 입력 계약
- 공개 소스 목록 정의 파일
- 다운로드 URL / 크롤링 URL / API endpoint / 덤프 패턴
- 이전 실행의 누적 단어 레지스트리
- 실행 설정 파일(배치 크기, 소스 우선순위, 필터 규칙, 저장 경로 등)

## 출력 계약
- 영구 누적 단어 저장소
- 이번 실행에서 새로 추가된 단어 목록
- 소스별 수집 통계
- 실패 로그 / 재시도 로그
- AI/스크립트가 조회하기 쉬운 단어 샤드 파일
- 전체 메타데이터 DB

## 고정 워크플로우
1. 소스 목록 로드
2. 증분 대상 소스 판정
3. 다운로드/크롤링
4. 텍스트/엔트리 파싱
5. 토큰 추출
6. 정규화 + 캐노니컬 키 생성
7. 빠른 필터(Bloom/Cuckoo)
8. 정확 중복 검사(Exact registry)
9. 신규 단어만 저장
10. 샤드/메타DB 업데이트
11. 통계/로그/리포트 생성

상세 규칙은 `docs/workflow_and_states.md`를 따른다.

## 판단과 코드의 역할 분리
이 항목은 항상 본문에 유지한다.

### 스크립트로 처리
- 설정 파일 로드, 스키마 검증
- 이전 실행 이력 비교, 날짜/버전 비교
- HTTP 다운로드, 압축 해제, 체크섬 검증, 재개 다운로드
- XML/JSONL/TXT/WET/WARC 스트리밍 파싱
- regex/tokenizer 기반 추출
- Unicode NFKC, 공백/제어문자 정리, case/canonical key 생성, 해시 생성
- Bloom/Cuckoo lookup, exact registry lookup, batch insert
- Parquet shard append/rewrite, LMDB/RocksDB insert, DuckDB metadata update
- 규칙 기반 품질 통계, 샘플링
- JSON/Markdown 리포트 생성

### LLM/에이전트가 직접 판단
- 소스 우선순위와 신규 소스 채택 여부
- 저장 공간 대비 가치 판단과 증분 수집 우선순위
- 포맷 이상치 분류와 신규 포맷 대응 방침
- 토큰 경계 규칙 개선안과 노이즈 패턴 분석
- 과도한 정규화 병합 여부 판단
- dedupe 이상 징후와 false positive 해석
- 샤딩 재배치/압축 정책 판단
- 품질/노이즈 정성 분석
- 사람이 보기 쉬운 실행 요약

### 사용자 확인으로 넘길 것
- 자동 규칙 변경이 기존 canonical/dedupe 정책을 깨뜨릴 가능성이 큰 경우
- 신규 소스 채택이 라이선스/운영 정책에 영향을 주는 경우
- 대규모 구조 변경, 저장 포맷 변경, 기존 데이터 재색인 필요 시

상세 에이전트 역할은 `docs/ai_and_script_role_split.md`를 따른다.

## 다중 AI 더블체크 규칙
- 판단이 필요한 단계마다 `도메인 담당 1 + 독립 리뷰 2 + tie-breaker 1` 구조를 적용한다.
- reviewer들은 서로의 답을 보지 않고 독립 검토한다.
- 3개 중 2개가 일치하면 승인한다.
- 충돌이 크면 tie-breaker가 최종 판정한다.
- 합의 실패 시 `REVIEW_CONFLICT`로 기록하고 재시도 또는 에스컬레이션한다.

## 필수 데이터/저장 원칙
- 주 저장소는 `Parquet shard + exact registry(LMDB/RocksDB) + DuckDB catalog` 조합을 우선 검토한다.
- 중복 제거는 `빠른 필터 + exact registry` 2단계로 처리한다.
- `token_raw`, `token_canonical`, `token_hash`, `source_id`, `run_id`, `first_seen_at`, `quality_flags`, `tier`는 유지한다.
- raw / stage / warehouse / registry / catalog / output 구조를 분리한다.

상세 스키마는 `docs/storage_and_dedup.md`를 따른다.

## 토큰화/정규화 원칙
- 수집량 최대화를 위해 넓게 추출하고 후속 티어링으로 분리한다.
- 알파벳, 숫자 혼합, 하이픈, 아포스트로피, 약어성 표기를 수용한다.
- 원칙상 `token_canonical` 기준 dedupe를 수행하되 raw variant는 별도 저장 가능하게 설계한다.
- 과도한 병합이 의심되면 자동 확정하지 말고 검토 로그를 남긴다.

상세 규칙은 `docs/tokenization_and_normalization.md`를 따른다.

## 수정 원칙
- 기존 구조를 유지하면서 필요한 범위만 최소 수정한다.
- 수집량·dedupe·증분 실행·출력 계약을 깨는 구조 개편은 금지한다.
- 테스트 없이 핵심 로직을 교체하지 않는다.
- 예외를 무조건 숨기지 말고 재시도/에스컬레이션/스킵 정책 중 하나로 명시 처리한다.

## 금지사항
- 수집량 최대화 목표를 “정답 단어만 남기기” 방향으로 바꾸지 않는다.
- 전체 메모리 적재 전제 구현을 하지 않는다.
- exact registry 없이 Bloom/Cuckoo만으로 dedupe를 끝내지 않는다.
- 원본 설계서에 없는 임의 출력 형식 변경을 하지 않는다.
- 검증 없는 핵심 라이브러리 교체를 하지 않는다.
- QA를 위한 별도 전용 앱을 만들지 않는다.
- 실제 사용자 경로와 다른 가짜 테스트 경로만으로 완료 처리하지 않는다.

## QA / 완료 기준
- 실제 프로젝트 코드 경로를 사용해 검증한다.
- 문서/코드 변경 시 QA 전문 에이전트가 실제 동작을 수행해 검증한다.
- QA는 각 요소별로 3~4개 단어 정도만 추출해 빠르게 샘플 검증한다.
- 핵심 성공 기준:
  - 기존 저장소 재삽입 없음
  - 신규 단어만 추가됨
  - 소스/배치/로그/메타데이터 일관성 유지
  - 지정된 출력 구조 생성
  - 원본 설계서 대비 누락 0%
- 상세 기준은 `docs/testing_and_qa.md`, `docs/omission_crosswalk.md`를 따른다.

## 권장 기술 스택
- Python
- requests/httpx
- warcio 또는 동급 WARC parser
- lxml / streaming XML parser
- regex / custom tokenizer
- DuckDB
- PyArrow / Parquet
- LMDB 또는 RocksDB 바인딩
- zstandard

## 참조 문서
- `docs/project_scope_and_goals.md`
- `docs/source_strategy.md`
- `docs/workflow_and_states.md`
- `docs/ai_and_script_role_split.md`
- `docs/tokenization_and_normalization.md`
- `docs/storage_and_dedup.md`
- `docs/testing_and_qa.md`
- `docs/implementation_structure.md`
- `docs/operations_runbook.md`
- `docs/omission_crosswalk.md`
