# docs/agents-and-skills-spec.md

## 1. 메인 오케스트레이터
### main-orchestrator
역할:
- 전체 흐름 조율
- 상태 전이 관리
- 서브에이전트 호출 순서 제어
- 재시도/에스컬레이션/QA 트리거 판정
- 최종 제출 가능 여부 승인

규칙:
- 서브에이전트 간 직접 호출을 허용하지 않는다.
- 모든 결과는 파일 기반 중간 산출물로 남기게 한다.
- 선택적 실패와 치명적 실패를 구분한다.

## 2. 서브에이전트

### spec-extractor
입력:
- PDF
- 페이지 렌더링
- raw text blocks
출력:
- section map
- raw spec list
역할:
- 데이터시트 섹션 분석
- 스펙 후보 식별
- 주석/그래프/표의 추출 대상 판정

### spec-normalizer
입력:
- raw spec JSON
출력:
- normalized spec JSON
- mapping candidates
역할:
- 스펙명 정규화
- 단위/카테고리 통일
- 비교 가능한 키 정리

### evidence-cropper
입력:
- spec JSON
- PDF 좌표 정보
출력:
- crop image files
- evidence index
역할:
- 의미 보존성 기준 crop 범위 결정
- 표 제목/머리글/footnote/축 포함 여부 판단

### comparison-judge
입력:
- comparison matrix candidate set
출력:
- 항목별 동일/차이/불확실 판정
역할:
- 매핑 항목의 비교 상태 계산
- 불확실 매핑 플래그 지정

### equivalence-judge
입력:
- comparison result
- package/pin/function info
- enrichment info
출력:
- 항목별 리스크 해석
- 종합 대체 적합성 판단
역할:
- 실무적 대체 가능 여부 해석
- 조건부 허용/비추천 기준 서술

### report-writer
입력:
- comparison result
- evidence index
출력:
- Excel/Word 구성 데이터
- 보고서 문안
역할:
- 사람이 빨리 판단할 수 있는 구조 생성
- 대표 근거 선택
- 핵심 차이 강조

### web-researcher
입력:
- original/candidate part number
출력:
- external_enrichment.json
역할:
- 제조사/공식 채널 정보 수집
- EOL/NRND/PCN/공식 대체품 권고 정리

### qa-reviewer
입력:
- 전체 산출물
- QA 샘플 데이터시트
- Plan 문서
출력:
- qa_validation_report.md
- rework_feedback.json
역할:
- 동일 코드 경로 전체 실행
- 생성된 Excel/Word 재검토
- 누락/오류/불일치 탐지
- 재코딩 피드백 생성

## 3. 스킬/스크립트 역할 및 트리거

### pdf-datasheet-reader
역할:
- PDF text block / bbox / page render 추출
트리거:
- 구조 분석 또는 스펙 추출 시작 시

### evidence-cropper
역할:
- bbox 기준 고해상도 crop 생성
트리거:
- 각 스펙의 근거 이미지 필요 시

### spec-normalizer
역할:
- 스펙명 정규화, 단위 환산, 카테고리 정리
트리거:
- raw spec 추출 완료 후

### comparison-report-builder
역할:
- Excel/Word 생성, 이미지 배치
트리거:
- 비교 결과 확정 후

### manufacturer-web-research
역할:
- 제조사/공식 채널 조사
트리거:
- 보고서 보강 정보 필요 시

### qa-system-runner
역할:
- QA 샘플로 실제 전체 시스템 실행
- 결과 산출물 재검토
트리거:
- 사용자 요청 / 코드 수정 / 문서 수정 / 릴리스 전

## 4. 데이터 전달 방식
권장 원칙:
- 큰 구조화 데이터는 JSON 파일
- crop 이미지는 파일 경로
- 로그/검증 결과는 md/json
- 프롬프트에는 요약만 넣고, 본 데이터는 파일로 남긴다
