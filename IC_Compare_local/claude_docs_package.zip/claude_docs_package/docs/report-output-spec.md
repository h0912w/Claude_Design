# docs/report-output-spec.md

## 1. 비교 기준
대체 적합성은 단순히 값이 비슷한지로 끝내지 않는다. 다음 관점을 반드시 포함한다.
1. 절대최대정격 일치/상회 여부
2. 권장 동작 조건 호환성
3. 전기 특성의 동일성 또는 허용 가능한 차이
4. 기능적 호환성
5. 패키지/핀 호환성
6. 열특성 / 타이밍 / 보호기능 차이
7. 테스트 조건 차이에 따른 수치 오해 가능성
8. 공식 제조사 정보 존재 여부

## 2. 최종 판정 등급
- A: 직접 대체 가능
- B: 조건부 대체 가능
- C: 주의 필요 / 추가 검증 필요
- D: 대체 비추천

Word에서는 같은 의미의 한글 표현으로 바꿔도 되지만 4단계 구조는 유지한다.

## 3. Excel 상세 규칙
### 비교 요약 시트
최소 컬럼:
- original spec
- candidate spec
- 비교 상태
- 차이 요약
- 대체 적합성 판단
- 주의사항
- 상세 시트 참조 위치

### original / candidate 상세 시트
최소 컬럼:
- category
- spec_name
- value
- condition
- unit
- note
- evidence image

규칙:
- 한 행은 하나의 스펙 또는 하나의 명확한 비교 단위에 대응한다.
- 행과 이미지 매칭이 깨지지 않도록 row anchor를 사용한다.
- 이미지가 셀 바깥에 떠서 정렬되지 않게 하지 않는다.
- 이미지가 너무 작아 판독 불가가 되지 않도록 한다.
- 표형 근거는 표 제목/헤더/footnote 포함 필요 여부를 우선 판단한다.
- 그래프형 근거는 축/단위/조건을 반드시 보이게 한다.

## 4. Word 상세 규칙
필수 내용:
- 비교 대상 부품 정보
- 핵심 결론
- 핵심 차이 항목
- 대체 가능/조건부 가능/비추천/추가검증필요 중 결론
- 사용 가능 조건 또는 비권장 사유
- 추가 확인 필요 항목
- 공식 제품 상태 또는 공식 정보 미발견 여부

문장 규칙:
- 근거 없는 단정 금지
- 차이가 있지만 허용 가능하면 그 전제 조건을 분명히 적는다.
- 비추천이면 무엇이 실제 리스크인지 적는다.
- “유사함”, “비슷함” 같은 모호한 말만 쓰지 말고 영향을 설명한다.

## 5. evidence index 규칙
각 evidence는 최소한 다음 정보를 권장한다.
- evidence_id
- part_role(original/candidate)
- linked_spec_id
- page
- bbox
- crop_path
- evidence_type(text/table/graph/package/pinout/note)
- representative(bool)

## 6. 중간 산출물 권장 형식
- `original_specs.json`
- `candidate_specs.json`
- `comparison_matrix.json`
- `comparison_assessment.json`
- `external_enrichment.json`
- `validation_report.json`
