# docs/workflow-and-state-machine.md

## 1. 전체 흐름
```text
[입력 검증]
   ↓
[original 구조 분석]
   ↓
[original 스펙 전체 추출]
   ↓
[original 근거 crop 생성]
   ↓
[candidate 구조 분석]
   ↓
[candidate 스펙 전체 추출]
   ↓
[candidate 근거 crop 생성]
   ↓
[스펙 정규화 및 1:1 매핑]
   ↓
[항목별 비교 및 적합성 판단]
   ↓
[공식/제조사 보강 정보 수집]
   ↓
[Excel 생성]
   ↓
[Word 생성]
   ↓
[산출물 검증 및 로그 기록]
   ↓
[QA 트리거 판정]
   ↓
[필수 QA 실행]
   ↓
[통과 또는 수정 피드백 생성]
```

## 2. 상태 전이
- `INIT` → `INPUT_VALIDATED`
- `INPUT_VALIDATED` → `ORIGINAL_PARSED`
- `ORIGINAL_PARSED` → `ORIGINAL_EVIDENCED`
- `ORIGINAL_EVIDENCED` → `CANDIDATE_PARSED`
- `CANDIDATE_PARSED` → `CANDIDATE_EVIDENCED`
- `CANDIDATE_EVIDENCED` → `COMPARED`
- `COMPARED` → `ENRICHED`
- `ENRICHED` → `DOCUMENTED`
- `DOCUMENTED` → `VALIDATED`
- `VALIDATED` → `DONE` 또는 `QA_PENDING`
- `QA_PENDING` → `QA_DONE`
- `QA_DONE` → `DONE` 또는 `REWORK_REQUIRED`
- `REWORK_REQUIRED` → 수정 후 `QA_PENDING`
- 치명적 실패는 언제든 `FAILED`
- 선택적 보강 정보만 실패하면 `PARTIAL_DONE`

## 3. 단계별 고정 규칙
### 단계 1. 입력 검증
- original 1개, candidate 1개가 식별되어야 한다.
- 디렉터리 구조, 확장자, 파일 존재를 검증한다.
- 입력 결과는 `input_manifest.json` 으로 저장한다.

### 단계 2. original 구조 분석
- 모든 페이지를 section map에 포함한다.
- 다음 범주를 최소 기준으로 탐색한다.
  - features
  - absolute max ratings
  - recommended operating conditions
  - electrical characteristics
  - thermal characteristics
  - timing
  - package
  - pin configuration
  - notes / footnotes
- 표/그래프/도면/주석도 스펙 대상 여부를 판정한다.

### 단계 3. original 전체 스펙 추출
- 표, 문장, 주석, 그래프에서 스펙 후보를 수집한다.
- 가능한 구조 필드:
  - category
  - spec_name
  - raw_label
  - value
  - unit
  - condition
  - note
  - source_page
  - source_bbox
  - evidence_refs
- 페이지별 재검토를 통해 누락 의심 항목을 다시 찾는다.

### 단계 4. original 근거 crop 생성
- 각 스펙마다 최소 1개 crop 또는 위치 정보를 남긴다.
- 단일 문장보다 의미 보존성이 높은 단위를 우선한다.
- 필요한 경우 표 일부 + footnote, 그래프 + 축을 함께 포함한다.
- 이 단계는 스킵 금지다.

### 단계 5~7. candidate 분석/추출/crop
- original과 동일 규칙을 candidate에 그대로 적용한다.

### 단계 8. 정규화 및 1:1 매핑
- 서로 다른 표현을 의미 기준으로 동등 매핑한다.
- 단위 차이는 환산 후 비교 가능 상태로 만든다.
- 모든 original 스펙은 matrix에 들어가야 한다.
- candidate 대응값이 없으면 unmatched 또는 미기재로 남긴다.
- 다대다 충돌은 자동 확정하지 않는다.

### 단계 9. 항목별 비교 및 적합성 판단
- 각 항목에 대해 다음 상태를 기본으로 사용한다.
  - 동일
  - 차이 있음
  - candidate 우위
  - candidate 열위
  - 불확실
  - 미기재
- 단순 수치 비교로 끝내지 않는다.
- 다음 관점을 반드시 본다.
  - 절대최대정격
  - 권장동작조건
  - 전기특성
  - 기능 호환성
  - 패키지/핀 호환성
  - 열특성
  - 타이밍
  - 보호기능 차이
  - 테스트 조건 차이

### 단계 10. 공식/제조사 보강 정보
- 제조사 공식 페이지, PCN/EOL/NRND, 공식 대체품 권고를 우선 수집한다.
- 없으면 “공식 정보 미발견”으로 남긴다.
- 선택 단계이지만, 수행했다면 출처를 구조화 저장한다.

### 단계 11. Excel 생성
- 비교 요약, original 상세, candidate 상세의 3시트 구조를 유지한다.
- 상세 시트의 각 스펙 행에 대표 근거 이미지를 연결한다.
- 이미지가 셀 내부에 삽입/고정되도록 한다.

### 단계 12. Word 생성
- 결론은 A/B/C/D 등급 또는 동일 의미의 4단계 판단으로 명확히 표기한다.
- 단순 찬반이 아니라 이유와 리스크를 적는다.

### 단계 13. 산출물 검증
- 행 수, 시트 수, 이미지 수, 필수 결론 존재 여부를 확인한다.
- 누락 의심 항목을 남기지 말고 validation report에 기록한다.

### 단계 14. QA 실행
- 실제 사용자용 코드 경로 그대로 실행한다.
- 샘플 입력으로 Excel/Word를 생성한다.
- 생성 산출물을 다시 읽는다.
- Plan 문서 기준으로 누락/오류를 찾는다.
- 특히 아래 2가지를 최우선 확인한다.
  1. 실제 데이터시트 대비 모든 스펙이 추출되었는가
  2. 근거 이미지가 셀 내부에 삽입/고정되었는가

## 4. 핵심 분기 조건
1. 텍스트 추출이 충분한가
   - 충분: 텍스트 기반 파싱 주도
   - 부족: 렌더링/시각 기반 분석 비중 증가

2. 표/문장만으로 의미가 충분한가
   - 충분: 단일 crop
   - 부족: footnote/축/조건 포함 crop

3. 동등 매핑이 명확한가
   - 명확: 자동 비교
   - 불명확: 불확실 매핑 표시 + 사람 검토 플래그

4. 차이가 실제 리스크를 만드는가
   - 예: 위험 또는 비추천
   - 아니오: 조건부 허용 또는 문제 없음

5. 공식 보강 정보가 있는가
   - 예: 보고서 반영
   - 아니오: 정보 미발견 기록
