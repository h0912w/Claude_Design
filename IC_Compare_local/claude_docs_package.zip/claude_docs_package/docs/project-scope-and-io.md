# docs/project-scope-and-io.md

## 1. 프로젝트 목적
이 시스템의 목적은 단종 또는 수급 불안정 회로소자에 대해, 사용자가 선정한 대체품 후보가 실제로 적합한지 판단하는 자료를 자동 생성하는 것이다.

핵심 목표:
1. 기존 부품 데이터시트에서 모든 스펙을 100% 빠짐없이 추출
2. 각 스펙의 근거 원문/원도표/원도면을 원본 그대로 crop 연결
3. 대체 후보에 대해서도 동일 처리
4. 스펙 일대일 비교표 생성
5. AI 기반 종합 적합성 판단 보고서 생성
6. 필요 시 제조사/공식 채널 보강 정보 첨부

## 2. 포함 범위
- 디지털 PDF 데이터시트 입력
- original 1개 + candidate 1개 기본 처리
- 파일명에서 part number 식별
- 스펙/조건/주석/도표/패키지/핀정보/전기특성/타이밍/열특성 추출
- 스펙 근거 이미지 crop
- Excel 3개 시트 생성
- Word 종합 판단 보고서 생성
- 제조사/공식 채널 기반 웹 정보 수집

## 3. 제외 범위
- 회로 전체 문맥 자동 해석
- SPICE 자동 시뮬레이션
- 실측 검증 자동화
- 스캔본 OCR 중심 최적화
- 다중 후보 순위화 상세 구현

## 4. 입력 계약
루트 구조:
```text
/project-root
 ├── /input
 │   ├── /original
 │   │   └── <기존부품_정확한PartNumber>.pdf
 │   └── /candidate
 │       └── <대체부품_정확한PartNumber>.pdf
```

입력 규칙:
- 파일명은 실제 구매 단위의 정확한 Part Number 풀네임
- 형식은 디지털 PDF 우선
- 영어 중심 데이터시트 가정, 다국어 일부 허용
- 페이지 수/표 구조/그래프/섹션 구조는 제조사별 상이 가능

## 5. 출력 계약
루트 구조:
```text
/project-root
 ├── /output
 │   ├── comparison_report.xlsx
 │   ├── substitution_assessment.docx
 │   ├── /crops
 │   │   ├── /original
 │   │   └── /candidate
 │   ├── /qa
 │   │   ├── /input
 │   │   │   ├── /original
 │   │   │   └── /candidate
 │   │   ├── /artifacts
 │   │   └── /reports
 │   ├── /intermediate
 │   │   ├── original_specs.json
 │   │   ├── candidate_specs.json
 │   │   ├── comparison_matrix.json
 │   │   └── evidence_index.json
 │   └── /logs
 │       └── run_log.md
```

## 6. Excel 계약
### 시트 1: 비교 요약
- original spec 항목
- candidate spec 항목
- 동일 여부
- 차이 요약
- 대체 적합성 판단
- 주의사항
- 상세 시트 참조 위치

### 시트 2: original 상세
- 카테고리
- 스펙명
- 값
- 조건
- 단위
- 비고
- 근거 crop 이미지

### 시트 3: candidate 상세
- 카테고리
- 스펙명
- 값
- 조건
- 단위
- 비고
- 근거 crop 이미지

## 7. Word 계약
권장 섹션:
1. 개요
2. 비교 대상 부품 정보
3. 핵심 결론
4. 항목별 주요 차이 요약
5. 대체 가능성 종합 판단
6. 사용 가능 조건 / 비권장 사유
7. 추가 확인 필요 항목
8. 제조사 권장 대체품 / 공식 상태 정보
9. 최종 권고

## 8. 성공 기준
- 스펙 누락 없이 구조화
- 각 스펙에 최소 1개 이상의 근거 crop 또는 위치 정보 연결
- 동일/차이/불확실/미기재 표기 명확
- AI 판단 이유를 사람이 즉시 추적 가능
- QA에서 실제 데이터시트 기준 스펙 완전성 검증
- QA에서 엑셀 셀 내부 이미지 삽입 상태 검증
